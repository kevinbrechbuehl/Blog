﻿namespace Unic.ReversibleCommand
{
    /// <summary>
    /// Interface for a command for the command design pattern
    /// </summary>
    public interface ICommand
    {
        /// <summary>
        /// Executes this instance.
        /// </summary>
        /// <returns><c>true</c> if command has successfully executed, <c>false</c> otherwise.</returns>
        bool Execute();

        /// <summary>
        /// Reverses this instance.
        /// </summary>
        void Reverse();
    }
}
