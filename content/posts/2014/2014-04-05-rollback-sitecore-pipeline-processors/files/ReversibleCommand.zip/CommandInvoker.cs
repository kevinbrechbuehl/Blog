﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Unic.ReversibleCommand
{
    /// <summary>
    /// Command invoker for the command design pattern
    /// </summary>
    public class CommandInvoker
    {
        /// <summary>
        /// Stores all commands in the chain
        /// </summary>
        private SynchronizedCollection<ICommand> commands = new SynchronizedCollection<ICommand>();

        /// <summary>
        /// Stack for all commandes which are executed
        /// </summary>
        private Stack<ICommand> executedCommands;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommandInvoker"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public CommandInvoker(string name)
        {
            this.Name = name;
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Adds the command.
        /// </summary>
        /// <param name="command">The command.</param>
        public void AddCommand(ICommand command)
        {
            this.commands.Add(command);
        }

        /// <summary>
        /// Executes all commands added to the chain and rollback all executions if something went wrong at any time..
        /// </summary>
        /// <returns><c>true</c> if every command has successfully executed, <c>false</c> otherwise.</returns>
        public bool Execute()
        {
            Monitor.Enter(this.commands.SyncRoot);
            try
            {
                if (this.commands.Count > 0)
                {
                    this.executedCommands = new Stack<ICommand>();
                    foreach (ICommand command in this.commands)
                    {
                        this.executedCommands.Push(command);
                        if (!command.Execute())
                        {
                            throw new Exception(string.Format("Error while processing command '{0}'", command.ToString()));
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(string.Format("Error while processing commands '{0}'", this.Name), ex, this);
                this.Rollback();
                return false;
            }
            finally
            {
                Monitor.Exit(this.commands.SyncRoot);
            }
        }

        /// <summary>
        /// Rollbacks all executed commands.
        /// </summary>
        private void Rollback()
        {
            Sitecore.Diagnostics.Log.Info(string.Format("Processing rollback for commands '{0}'", this.Name), this);
            if (this.executedCommands != null && this.executedCommands.Count > 0)
            {
                while (this.executedCommands.Count > 0)
                {
                    ICommand command = this.executedCommands.Pop();
                    try
                    {
                        command.Reverse();
                    }
                    catch (Exception ex)
                    {
                        Sitecore.Diagnostics.Log.Error(string.Format("Error while reversing command '{0}'", command.ToString()), ex, this);
                    }
                }
            }
        }
    }
}
